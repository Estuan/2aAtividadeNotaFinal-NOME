<?php
require 'database.php';

$id = $_POST['id'] ?? null;

if ($id) {
    $stmt = $db->prepare("UPDATE tarefas SET concluida = 1 WHERE id = ?");
    $stmt->execute([$id]);
}

header('Location: index.php');
exit;
?>
