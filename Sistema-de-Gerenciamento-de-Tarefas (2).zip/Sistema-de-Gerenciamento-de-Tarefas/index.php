<?php
require 'database.php';


$tarefas = $db->query("SELECT * FROM tarefas ORDER BY concluida ASC, data_vencimento ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Tarefas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #a3a2a2;
            max-width: 799px;
            margin: auto;
            padding: 39px;
        }

        h1 {
            color: #333;
        }

        form {
            margin-bottom: 24px;
        }

        input[type="text"], input[type="date"] {
            padding: 7px;
            width: 249px;
            margin-right: 9px;
        }

        button {
            padding: 8px 14px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        table {
            width: 100%;
            background-color: white;
            border-collapse: collapse;
        }

        th, td {
            padding: 11px;
            border: 1px solid #ccc;
        }

        .concluida {
            text-decoration: line-through;
            color: gray;
        }

        .btn-concluir {
            background: #28a745;
            color: white;
            border: none;
            padding: 5px 9px;
            cursor: pointer;
        }

        .btn-excluir {
            background: #dc3545;
            color: white;
            border: none;
            padding: 5px 9px;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <h1>📝 Minha Lista de Tarefas</h1>

   
    <form method="POST" action="add_tarefa.php">
        <input type="text" name="descricao" placeholder="Descrição da tarefa" required>
        <input type="date" name="data_vencimento" required>
        <button type="submit">Adicionar</button>
    </form>

    <?php if (count($tarefas) === 0): ?>
        <p>Nenhuma tarefa no momento.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Descrição</th>
                <th>Vencimento</th>
                <th>Status</th>
                <th>opções</th>
            </tr>

            <?php foreach ($tarefas as $tarefa): ?>
                <tr>
                    <td class="<?= $tarefa['concluida'] ? 'concluida' : '' ?>">
                        <?= htmlspecialchars($tarefa['descricao']) ?>
                    </td>
                    <td><?= htmlspecialchars($tarefa['data_vencimento']) ?></td>
                    <td><?= $tarefa['concluida'] ? '✔️ Concluída' : '⏳ Pendente' ?></td>
                    <td>
                        <?php if (!$tarefa['concluida']): ?>
                            <form method="POST" action="update_tarefa.php" style="display:inline;">
                                <input type="hidden" name="id" value="<?= $tarefa['id'] ?>">
                                <button type="submit" class="btn-concluir">Concluir</button>
                            </form>
                        <?php endif; ?>

                        <form method="POST" action="delete_tarefa.php" style="display:inline;" onsubmit="return confirm('Deseja excluir esta tarefa?');">
                            <input type="hidden" name="id" value="<?= $tarefa['id'] ?>">
                            <button type="submit" class="btn-excluir">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>

        </table>
    <?php endif; ?>

</body>
</html>
