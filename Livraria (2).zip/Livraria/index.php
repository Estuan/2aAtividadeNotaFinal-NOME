<?php

require 'database.php';


$livros = $db->query("SELECT * FROM livros ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title> Livraria</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #fdfdfd;
            padding: 30px;
            max-width: 800px;
            margin: auto;
        }

        h1, h2 {
            color: #444;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }

        th {
            background-color: #eee;
        }

        form {
            margin-top: 29px;
        }

        input[type="text"], input[type="number"] {
            padding: 7px;
            margin: 4px 0;
            width: 100%;
            max-width: 299px;
        }

        input[type="submit"] {
            padding: 7px 14px;
            background: #a30b0b;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background: #93bf9d;
        }

        .delete-btn {
            background: #dc3545;
        }

        .delete-btn:hover {
            background: #c82333;
        }
    </style>
</head>
<body>
    <h1>📖 Livros Cadastrados</h1>

    <?php if (count($livros) === 0): ?>
        <p>Nenhum livro cadastrado ainda.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Autor</th>
                <th>Ano</th>
                <th>Ações</th>
            </tr>
            <?php foreach ($livros as $livro): ?>
                <tr>
                    <td><?= htmlspecialchars($livro['id']) ?></td>
                    <td><?= htmlspecialchars($livro['titulo']) ?></td>
                    <td><?= htmlspecialchars($livro['autor']) ?></td>
                    <td><?= htmlspecialchars($livro['ano']) ?></td>
                    <td>
                        <form method="POST" action="delete_book.php" onsubmit="return confirm('Tem certeza que deseja excluir?');">
                            <input type="hidden" name="id" value="<?= $livro['id'] ?>">
                            <input type="submit" value="Excluir" class="delete-btn">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <h2>➕ Adicionar Novo Livro</h2>
    <form method="POST" action="add_book.php">
        <label>Título:</label><br>
        <input type="text" placeholder="Titulo" name="titulo" required><br>

        <label>Autor:</label><br>
        <input type="text" name="autor"         <input type="text" placeholder="Autor" name="autor"  required><br> 

        <label>Ano:</label><br>
        <input type="number" placeholder="Ano" name="ano" required><br><br>

        <input type="submit" value="Salvar Livro">
    </form>
</body>
</html>
