<?php

require 'database.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = trim($_POST['titulo'] ?? '');
    $autor = trim($_POST['autor'] ?? '');
    $ano = (int) ($_POST['ano'] ?? 0);

    
    if (!empty($titulo) && !empty($autor) && $ano > 0) {
        $stmt = $db->prepare("INSERT INTO livros (titulo, autor, ano) VALUES (?, ?, ?)");
        $stmt->execute([$titulo, $autor, $ano]);
    }
}
header('Location: index.php');
exit;
?>
